math4j
======

A library for mathematics calculating, including statistics, linear algebra, FFT, DCT, DHT, data structures and so on.
