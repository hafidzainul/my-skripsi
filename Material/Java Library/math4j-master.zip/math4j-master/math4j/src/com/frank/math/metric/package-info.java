/*
 * Copyright (c) 2011, 2020, Frank Jiang and/or its affiliates. All rights
 * reserved.
 * package-info.java is PROPRIETARY/CONFIDENTIAL built in 下午11:53:18,
 * 2014年12月25日.
 * Use is subject to license terms.
 */
/**
 * The package for metrics.
 * <p>
 * </p>
 * 
 * @author <a href="mailto:jiangfan0576@gmail.com">Frank Jiang</a>
 * @version 1.0.0
 */
package com.frank.math.metric;