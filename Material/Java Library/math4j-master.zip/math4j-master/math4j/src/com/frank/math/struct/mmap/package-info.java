/*
 * Copyright (c) 2011, 2020, Frank Jiang and/or its affiliates. All rights
 * reserved.
 * package-info.java is PROPRIETARY/CONFIDENTIAL built in 8:06:00 PM, Sep 8,
 * 2015.
 * Use is subject to license terms.
 */
/**
 * The package of multiple elements map.
 * <p>
 * </p>
 * 
 * @author <a href="mailto:jiangfan0576@gmail.com">Frank Jiang</a>
 * @version 1.0.0
 */
package com.frank.math.struct.mmap;